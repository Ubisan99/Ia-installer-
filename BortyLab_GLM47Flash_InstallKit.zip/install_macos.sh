#!/bin/bash
# ============================================================
# 🚀 GLM-4.7-Flash — Installazione Completa per macOS
# Supporta: Mac Mini M4, MacBook Pro/Air, Mac Studio, iMac
# Apple Silicon (M1/M2/M3/M4/M5) + Intel
# By BortyLab 🧪
# ============================================================

set -e

# Colori
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m' # No Color
BOLD='\033[1m'

print_header() {
    echo ""
    echo -e "${MAGENTA}╔══════════════════════════════════════════════╗${NC}"
    echo -e "${MAGENTA}║${NC}  ${BOLD}🧪 BortyLab — GLM-4.7-Flash Installer${NC}       ${MAGENTA}║${NC}"
    echo -e "${MAGENTA}║${NC}  ${CYAN}macOS Edition (Apple Silicon + Intel)${NC}       ${MAGENTA}║${NC}"
    echo -e "${MAGENTA}╚══════════════════════════════════════════════╝${NC}"
    echo ""
}

print_step() {
    echo -e "${CYAN}[$(date +%H:%M:%S)]${NC} ${BOLD}$1${NC}"
}

print_ok() {
    echo -e "  ${GREEN}✅ $1${NC}"
}

print_warn() {
    echo -e "  ${YELLOW}⚠️  $1${NC}"
}

print_err() {
    echo -e "  ${RED}❌ $1${NC}"
}

# ============================================================
print_header

# --- Verifica macOS ---
if [[ "$(uname)" != "Darwin" ]]; then
    print_err "Questo script è per macOS. Usa lo script Linux o Windows."
    exit 1
fi

# --- Info Sistema ---
print_step "Rilevamento sistema..."

ARCH=$(uname -m)
TOTAL_RAM=$(sysctl -n hw.memsize 2>/dev/null)
TOTAL_RAM_GB=$((TOTAL_RAM / 1073741824))
OS_VERSION=$(sw_vers -productVersion 2>/dev/null || echo "unknown")
CHIP=$(sysctl -n machdep.cpu.brand_string 2>/dev/null || echo "Unknown")

echo ""
echo -e "  ${BOLD}Chip:${NC}     $CHIP"
echo -e "  ${BOLD}Arch:${NC}     $ARCH"
echo -e "  ${BOLD}RAM:${NC}      ${TOTAL_RAM_GB}GB unified memory"
echo -e "  ${BOLD}macOS:${NC}    $OS_VERSION"
echo ""

# Controlla RAM minima
if [ "$TOTAL_RAM_GB" -lt 8 ]; then
    print_err "Servono almeno 8GB di RAM. Hai ${TOTAL_RAM_GB}GB."
    exit 1
elif [ "$TOTAL_RAM_GB" -lt 16 ]; then
    print_warn "Con ${TOTAL_RAM_GB}GB la RAM è limitata. Useremo Q2_K (~3GB)"
    RECOMMENDED_QUANT="q2_k"
    RECOMMENDED_CTX=2048
elif [ "$TOTAL_RAM_GB" -lt 24 ]; then
    print_ok "16GB OK — Useremo Q4_K_M (~5GB) con contesto 4K"
    RECOMMENDED_QUANT="q4_k_m"
    RECOMMENDED_CTX=4096
elif [ "$TOTAL_RAM_GB" -lt 48 ]; then
    print_ok "${TOTAL_RAM_GB}GB — Useremo Q4_K_M (~5GB) con contesto 8K"
    RECOMMENDED_QUANT="q4_k_m"
    RECOMMENDED_CTX=8192
else
    print_ok "${TOTAL_RAM_GB}GB — Puoi usare Q8_0 (~10GB) con contesto 16K+"
    RECOMMENDED_QUANT="q8_0"
    RECOMMENDED_CTX=16384
fi

echo ""

# --- 1. Homebrew ---
print_step "Controllo Homebrew..."

if command -v brew &> /dev/null; then
    print_ok "Homebrew già installato"
else
    print_warn "Homebrew non trovato. Installazione..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

    # Aggiungi brew al PATH per Apple Silicon
    if [[ "$ARCH" == "arm64" ]]; then
        echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
        eval "$(/opt/homebrew/bin/brew shellenv)"
    fi
    print_ok "Homebrew installato"
fi

# --- 2. Dipendenze utili ---
print_step "Installazione dipendenze..."

# curl (di solito già presente su macOS)
if command -v curl &> /dev/null; then
    print_ok "curl presente"
else
    brew install curl
    print_ok "curl installato"
fi

# jq — utile per parsare le risposte JSON dell'API
if command -v jq &> /dev/null; then
    print_ok "jq presente"
else
    brew install jq
    print_ok "jq installato"
fi

# Python 3 (per script e libreria ollama)
if command -v python3 &> /dev/null; then
    PY_VERSION=$(python3 --version 2>&1)
    print_ok "Python: $PY_VERSION"
else
    brew install python@3.12
    print_ok "Python 3.12 installato"
fi

# pip
if python3 -m pip --version &> /dev/null; then
    print_ok "pip presente"
else
    python3 -m ensurepip --upgrade
    print_ok "pip installato"
fi

# Libreria Python ollama
print_step "Installazione libreria Python ollama..."
python3 -m pip install --quiet --upgrade ollama
print_ok "ollama (Python) installato"

# Libreria openai (compatibilità API)
python3 -m pip install --quiet --upgrade openai
print_ok "openai (Python) installato"

# --- 3. Ollama ---
print_step "Installazione Ollama..."

if command -v ollama &> /dev/null; then
    OLLAMA_V=$(ollama --version 2>/dev/null || echo "installed")
    print_ok "Ollama già installato: $OLLAMA_V"
else
    brew install ollama
    print_ok "Ollama installato via Homebrew"
fi

echo ""

# --- 4. Avvia Server ---
print_step "Avvio server Ollama..."

if curl -s http://localhost:11434/api/tags &> /dev/null; then
    print_ok "Server già in esecuzione"
else
    ollama serve &>/dev/null &
    sleep 3

    if curl -s http://localhost:11434/api/tags &> /dev/null; then
        print_ok "Server avviato su http://localhost:11434"
    else
        print_warn "Server in avvio... attendo ancora..."
        sleep 5
    fi
fi

echo ""

# --- 5. Download modello ---
print_step "Download GLM-4.7-Flash..."
echo -e "  ${CYAN}Quantizzazione consigliata: ${BOLD}${RECOMMENDED_QUANT}${NC}"
echo -e "  ${CYAN}Questo può richiedere qualche minuto...${NC}"
echo ""

ollama pull glm-4.7-flash

print_ok "Modello scaricato!"
echo ""

# --- 6. Test rapido ---
print_step "Test rapido..."
echo ""

RESPONSE=$(curl -s http://localhost:11434/api/generate \
    -d "{\"model\":\"glm-4.7-flash\",\"prompt\":\"Rispondi in massimo 10 parole: sei operativo?\",\"stream\":false}" \
    | python3 -c "import sys,json; print(json.load(sys.stdin).get('response','Errore nel test'))" 2>/dev/null || echo "Test completato")

echo -e "  ${GREEN}🤖 GLM-4.7-Flash: ${RESPONSE}${NC}"
echo ""

# --- 7. Crea script di avvio rapido ---
LAUNCH_SCRIPT="$HOME/.local/bin/glm-chat"
mkdir -p "$HOME/.local/bin"

cat > "$LAUNCH_SCRIPT" << 'SCRIPT'
#!/bin/bash
# Avvio rapido GLM-4.7-Flash
if ! curl -s http://localhost:11434/api/tags &> /dev/null; then
    echo "🔄 Avvio Ollama..."
    ollama serve &>/dev/null &
    sleep 3
fi
echo "🧪 BortyLab — GLM-4.7-Flash Chat"
echo "Digita /bye per uscire"
echo ""
ollama run glm-4.7-flash
SCRIPT

chmod +x "$LAUNCH_SCRIPT"

# Aggiungi al PATH se necessario
if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc
    export PATH="$HOME/.local/bin:$PATH"
fi

print_ok "Shortcut creato: glm-chat"
echo ""

# --- Riepilogo Finale ---
echo -e "${MAGENTA}╔══════════════════════════════════════════════╗${NC}"
echo -e "${MAGENTA}║${NC}  ${GREEN}${BOLD}🎉 INSTALLAZIONE COMPLETATA!${NC}                ${MAGENTA}║${NC}"
echo -e "${MAGENTA}╚══════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BOLD}Comandi rapidi:${NC}"
echo ""
echo -e "  ${CYAN}glm-chat${NC}                         → Chat interattiva"
echo -e "  ${CYAN}ollama run glm-4.7-flash${NC}         → Chat diretta"
echo -e "  ${CYAN}ollama run glm-4.7-flash --num-ctx ${RECOMMENDED_CTX}${NC}"
echo ""
echo -e "  ${BOLD}API locale (compatibile OpenAI):${NC}"
echo -e "  ${CYAN}http://localhost:11434/v1/chat/completions${NC}"
echo ""
echo -e "  ${BOLD}Consigli per ${TOTAL_RAM_GB}GB RAM:${NC}"
echo -e "  Quant: ${GREEN}${RECOMMENDED_QUANT}${NC} | Contesto: ${GREEN}${RECOMMENDED_CTX} token${NC}"
echo ""
echo -e "  ${BOLD}🧪 BortyLab — Buon hacking!${NC}"
echo ""
