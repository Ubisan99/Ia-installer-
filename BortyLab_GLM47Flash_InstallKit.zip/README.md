# 🧪 BortyLab — GLM-4.7-Flash Local Install Kit

Script di installazione completa per **GLM-4.7-Flash** via **Ollama** su tutti i sistemi operativi.

---

## 📦 Contenuto

| File | Sistema | Descrizione |
|------|---------|-------------|
| `install_macos.sh` | macOS | Apple Silicon (M1–M5) + Intel |
| `install_linux.sh` | Linux | Ubuntu, Debian, Fedora, Arch, etc. |
| `install_windows.ps1` | Windows | Windows 10/11, PowerShell |
| `test_glm47.py` | Tutti | Test, benchmark, verifica dipendenze |

---

## 🚀 Installazione Rapida

### macOS (Mac Mini M4, MacBook, Mac Studio)

```bash
chmod +x install_macos.sh
./install_macos.sh
```

### Linux (Ubuntu/Debian/Fedora/Arch)

```bash
chmod +x install_linux.sh
sudo ./install_linux.sh
```

### Windows (PowerShell come Amministratore)

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\install_windows.ps1
```

---

## ✅ Dopo l'installazione

### Test completo (tutti i sistemi)

```bash
python3 test_glm47.py
```

### Chat rapida

```bash
ollama run glm-4.7-flash
```

### Shortcut (creato automaticamente)

```bash
glm-chat
```

---

## 💻 Requisiti Hardware

| RAM | Quantizzazione | Contesto | Esperienza |
|-----|---------------|----------|------------|
| 8GB | Q2_K (~3GB) | 2K token | Minimo, lento |
| 16GB | Q4_K_M (~5GB) | 4K token | Buona |
| 24GB | Q4_K_M (~5GB) | 8K token | Ottima |
| 32GB+ | Q8_0 (~10GB) | 8-16K | Eccellente |
| 48GB+ | Q8_0 (~10GB) | 16K+ | Massime prestazioni |

### GPU supportate

- **NVIDIA**: qualsiasi GPU con 6GB+ VRAM (GTX 1660+, RTX serie)
- **AMD**: supporto ROCm (meglio su Linux)
- **Apple Silicon**: M1/M2/M3/M4/M5 via Metal (memoria unificata)
- **CPU-only**: funziona, ma più lento (16GB RAM minimo)

---

## 🔌 API Locale

Dopo l'installazione, Ollama espone un'API compatibile OpenAI:

### Endpoint

```
http://localhost:11434/v1/chat/completions
```

### Esempio curl

```bash
curl http://localhost:11434/api/chat \
  -d '{
    "model": "glm-4.7-flash",
    "messages": [{"role": "user", "content": "Ciao!"}]
  }'
```

### Esempio Python (libreria ollama)

```python
from ollama import chat

response = chat(
    model='glm-4.7-flash',
    messages=[{'role': 'user', 'content': 'Scrivi una funzione Python per ordinare una lista'}],
)
print(response.message.content)
```

### Esempio Python (compatibilità OpenAI)

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:11434/v1",
    api_key="not-needed",
)

response = client.chat.completions.create(
    model="glm-4.7-flash",
    messages=[{"role": "user", "content": "Ciao!"}],
)
print(response.choices[0].message.content)
```

---

## 🔧 Comandi Utili

| Comando | Descrizione |
|---------|-------------|
| `ollama run glm-4.7-flash` | Chat interattiva |
| `ollama list` | Modelli installati |
| `ollama pull glm-4.7-flash` | Aggiorna modello |
| `ollama rm glm-4.7-flash` | Rimuovi modello |
| `ollama serve` | Avvia server |
| `ollama ps` | Modelli in esecuzione |

### Linux: gestione servizio

```bash
sudo systemctl start ollama
sudo systemctl stop ollama
sudo systemctl status ollama
sudo systemctl enable ollama   # avvio automatico
```

---

## ⚡ Tips per Prestazioni

1. **Chiudi app pesanti** prima di usare il modello (browser con molte tab, editor video)
2. **Contesto ridotto** se la RAM è limitata: `ollama run glm-4.7-flash --num-ctx 4096`
3. **NVIDIA**: imposta "Prefer Maximum Performance" nelle impostazioni driver
4. **macOS**: il primo caricamento è più lento, poi si scalda la cache
5. **Temperature**: per coding usa `temperature: 0.6-0.7`, per chat creativa `0.8-1.0`

---

## 📊 Benchmark di Riferimento

| Hardware | Quant | tok/s | Note |
|----------|-------|-------|------|
| Mac Mini M4 16GB | Q4_K_M | ~30-50 | Contesto 4K |
| MacBook M4 Pro 48GB | Q4_K_M | 60-85 | Contesto 8K |
| RTX 4090 24GB | Q4_K_M | 120-220 | Contesto 8K |
| RTX 3090 24GB | Q4_K_M | 90-170 | Contesto 8K |
| CPU-only 32GB | Q4_K_M | 5-15 | Lento ma funziona |

---

## 🧪 BortyLab

Creato con amore per il lab. Buon hacking!
