# ============================================================
# 🚀 GLM-4.7-Flash — Installazione Completa per Windows
# Supporta: Windows 10/11, NVIDIA GPU, AMD GPU, CPU-only
# Richiede: PowerShell 5.1+ (esegui come Amministratore)
# By BortyLab 🧪
# ============================================================

$ErrorActionPreference = "Stop"

# --- Colori ---
function Write-Header {
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════╗" -ForegroundColor Magenta
    Write-Host "  ║  🧪 BortyLab — GLM-4.7-Flash Installer      ║" -ForegroundColor Magenta
    Write-Host "  ║  Windows Edition (NVIDIA/AMD/CPU)            ║" -ForegroundColor Magenta
    Write-Host "  ╚══════════════════════════════════════════════╝" -ForegroundColor Magenta
    Write-Host ""
}

function Write-Step($msg)  { Write-Host "  [$((Get-Date).ToString('HH:mm:ss'))] $msg" -ForegroundColor Cyan }
function Write-Ok($msg)    { Write-Host "    ✅ $msg" -ForegroundColor Green }
function Write-Warn($msg)  { Write-Host "    ⚠️  $msg" -ForegroundColor Yellow }
function Write-Err($msg)   { Write-Host "    ❌ $msg" -ForegroundColor Red }

# ============================================================
Write-Header

# --- Verifica Admin ---
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Warn "Non sei Amministratore. Alcune installazioni potrebbero fallire."
    Write-Host "    Consiglio: click destro su PowerShell → 'Esegui come amministratore'" -ForegroundColor Yellow
    Write-Host ""
}

# --- Info Sistema ---
Write-Step "Rilevamento sistema..."

$totalRAM = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
$osName = (Get-CimInstance Win32_OperatingSystem).Caption
$cpuName = (Get-CimInstance Win32_Processor).Name
$arch = if ([Environment]::Is64BitOperatingSystem) { "x64" } else { "x86" }

Write-Host ""
Write-Host "    OS:       $osName" -ForegroundColor White
Write-Host "    CPU:      $cpuName" -ForegroundColor White
Write-Host "    Arch:     $arch" -ForegroundColor White
Write-Host "    RAM:      ${totalRAM}GB" -ForegroundColor White

# GPU detection
$gpuType = "cpu"
$gpuName = "Nessuna GPU dedicata"
$gpuVRAM = 0

try {
    $nvidiaSmi = & nvidia-smi --query-gpu=name,memory.total --format=csv,noheader 2>$null
    if ($nvidiaSmi) {
        $gpuType = "nvidia"
        $parts = $nvidiaSmi -split ","
        $gpuName = $parts[0].Trim()
        $gpuVRAM = [math]::Round([int]($parts[1].Trim() -replace '[^0-9]','') / 1024)
        Write-Host "    GPU:      $gpuName (${gpuVRAM}GB VRAM)" -ForegroundColor White
    }
} catch {
    # Prova AMD
    $amdGPU = Get-CimInstance Win32_VideoController | Where-Object { $_.Name -match "AMD|Radeon" }
    if ($amdGPU) {
        $gpuType = "amd"
        $gpuName = $amdGPU.Name
        Write-Host "    GPU:      $gpuName (AMD)" -ForegroundColor White
    } else {
        Write-Host "    GPU:      CPU-only mode" -ForegroundColor White
    }
}

Write-Host ""

# --- Raccomandazioni RAM ---
if ($totalRAM -lt 8) {
    Write-Err "Servono almeno 8GB di RAM. Hai ${totalRAM}GB."
    exit 1
} elseif ($totalRAM -lt 16) {
    $recommendedQuant = "q2_k"
    $recommendedCtx = 2048
    Write-Warn "RAM limitata (${totalRAM}GB) — Q2_K con contesto 2K"
} elseif ($totalRAM -lt 24) {
    $recommendedQuant = "q4_k_m"
    $recommendedCtx = 4096
    Write-Ok "16GB OK — Q4_K_M con contesto 4K"
} elseif ($totalRAM -lt 48) {
    $recommendedQuant = "q4_k_m"
    $recommendedCtx = 8192
    Write-Ok "${totalRAM}GB — Q4_K_M con contesto 8K"
} else {
    $recommendedQuant = "q8_0"
    $recommendedCtx = 16384
    Write-Ok "${totalRAM}GB — Q8_0 con contesto 16K+"
}

Write-Host ""

# --- 1. Winget (package manager) ---
Write-Step "Controllo winget..."

$hasWinget = Get-Command winget -ErrorAction SilentlyContinue
if ($hasWinget) {
    Write-Ok "winget presente"
} else {
    Write-Warn "winget non trovato. Installa 'App Installer' dal Microsoft Store."
    Write-Host "    https://apps.microsoft.com/detail/9NBLGGH4NNS1" -ForegroundColor Cyan
}

Write-Host ""

# --- 2. Dipendenze ---
Write-Step "Installazione dipendenze..."

# Python 3
$hasPython = Get-Command python -ErrorAction SilentlyContinue
if ($hasPython) {
    $pyVersion = & python --version 2>&1
    Write-Ok "Python: $pyVersion"
} else {
    Write-Warn "Python non trovato. Installazione..."
    if ($hasWinget) {
        winget install Python.Python.3.12 --accept-package-agreements --accept-source-agreements
        Write-Ok "Python 3.12 installato (riavvia il terminale per usarlo)"
    } else {
        Write-Warn "Installa Python da https://python.org/downloads/"
        Write-Host "    IMPORTANTE: seleziona 'Add Python to PATH' durante l'installazione!" -ForegroundColor Yellow
    }
}

# pip + librerie Python
try {
    & python -m pip install --quiet --upgrade ollama openai requests 2>$null
    Write-Ok "Librerie Python (ollama, openai) installate"
} catch {
    Write-Warn "pip non disponibile. Installa Python e riprova."
}

# Git (opzionale ma utile)
$hasGit = Get-Command git -ErrorAction SilentlyContinue
if ($hasGit) {
    Write-Ok "Git presente"
} else {
    Write-Warn "Git non trovato (opzionale). Installa con: winget install Git.Git"
}

# jq (opzionale)
$hasJq = Get-Command jq -ErrorAction SilentlyContinue
if ($hasJq) {
    Write-Ok "jq presente"
} else {
    if ($hasWinget) {
        try {
            winget install jqlang.jq --accept-package-agreements --accept-source-agreements 2>$null
            Write-Ok "jq installato"
        } catch {
            Write-Warn "jq non installato (opzionale)"
        }
    }
}

Write-Host ""

# --- 3. NVIDIA Driver Check ---
if ($gpuType -eq "nvidia") {
    Write-Step "Controllo driver NVIDIA..."

    try {
        $driverVersion = & nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>$null
        Write-Ok "Driver NVIDIA: $driverVersion"

        # Verifica CUDA
        $cudaVersion = & nvidia-smi 2>$null | Select-String "CUDA Version" | ForEach-Object { ($_ -split "CUDA Version:")[1].Trim() -replace "\s.*","" }
        if ($cudaVersion) {
            Write-Ok "CUDA: $cudaVersion"
        }
    } catch {
        Write-Warn "nvidia-smi non raggiungibile. Aggiorna i driver:"
        Write-Host "    https://www.nvidia.com/drivers/" -ForegroundColor Cyan
    }

    # Performance tip
    Write-Host ""
    Write-Host "    💡 Tip: Nelle impostazioni NVIDIA, imposta" -ForegroundColor Yellow
    Write-Host "       'Power Management' → 'Prefer Maximum Performance'" -ForegroundColor Yellow

} elseif ($gpuType -eq "amd") {
    Write-Step "GPU AMD rilevata"
    Write-Warn "Ollama supporta AMD via ROCm (sperimentale su Windows)"
    Write-Host "    Per prestazioni migliori usa Linux con ROCm" -ForegroundColor Yellow
}

Write-Host ""

# --- 4. Ollama ---
Write-Step "Installazione Ollama..."

$hasOllama = Get-Command ollama -ErrorAction SilentlyContinue
if ($hasOllama) {
    $ollamaV = & ollama --version 2>&1
    Write-Ok "Ollama già installato: $ollamaV"
} else {
    if ($hasWinget) {
        Write-Host "    Installazione via winget..." -ForegroundColor Cyan
        winget install Ollama.Ollama --accept-package-agreements --accept-source-agreements
        Write-Ok "Ollama installato"
        Write-Warn "Potrebbe essere necessario riavviare il terminale."
    } else {
        Write-Warn "Scarica Ollama manualmente:"
        Write-Host "    https://ollama.com/download/windows" -ForegroundColor Cyan
    }
}

Write-Host ""

# --- 5. Avvia Ollama ---
Write-Step "Avvio Ollama..."

try {
    $response = Invoke-WebRequest -Uri "http://localhost:11434/api/tags" -UseBasicParsing -TimeoutSec 3 -ErrorAction Stop
    Write-Ok "Server già in esecuzione"
} catch {
    Write-Host "    Avvio server in background..." -ForegroundColor Cyan
    Start-Process -FilePath "ollama" -ArgumentList "serve" -WindowStyle Hidden -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 4

    try {
        $response = Invoke-WebRequest -Uri "http://localhost:11434/api/tags" -UseBasicParsing -TimeoutSec 5
        Write-Ok "Server avviato su http://localhost:11434"
    } catch {
        Write-Warn "Server non raggiungibile. Avvia Ollama dal menu Start."
    }
}

Write-Host ""

# --- 6. Download modello ---
Write-Step "Download GLM-4.7-Flash..."
Write-Host "    Quantizzazione: $recommendedQuant" -ForegroundColor Cyan
Write-Host "    Potrebbe richiedere qualche minuto..." -ForegroundColor Cyan
Write-Host ""

& ollama pull glm-4.7-flash

Write-Ok "Modello scaricato!"
Write-Host ""

# --- 7. Test ---
Write-Step "Test rapido..."

try {
    $body = '{"model":"glm-4.7-flash","prompt":"Rispondi in max 10 parole: sei operativo?","stream":false}'
    $testResponse = Invoke-RestMethod -Uri "http://localhost:11434/api/generate" -Method POST -Body $body -ContentType "application/json" -TimeoutSec 60
    Write-Host "    🤖 GLM-4.7-Flash: $($testResponse.response)" -ForegroundColor Green
} catch {
    Write-Warn "Test non riuscito. Prova manualmente: ollama run glm-4.7-flash"
}

Write-Host ""

# --- 8. Crea shortcut batch ---
$batchPath = "$env:USERPROFILE\glm-chat.bat"

$batchContent = @"
@echo off
title BortyLab - GLM-4.7-Flash Chat
echo.
echo  ====================================
echo   BortyLab - GLM-4.7-Flash Chat
echo  ====================================
echo  Digita /bye per uscire
echo.
ollama run glm-4.7-flash
"@

Set-Content -Path $batchPath -Value $batchContent
Write-Ok "Shortcut creato: $batchPath"

Write-Host ""

# --- Riepilogo ---
Write-Host "  ╔══════════════════════════════════════════════╗" -ForegroundColor Magenta
Write-Host "  ║  🎉 INSTALLAZIONE COMPLETATA!                ║" -ForegroundColor Green
Write-Host "  ╚══════════════════════════════════════════════╝" -ForegroundColor Magenta
Write-Host ""
Write-Host "    Sistema:   $osName" -ForegroundColor White
Write-Host "    GPU:       $gpuName ($gpuType)" -ForegroundColor White
Write-Host "    RAM:       ${totalRAM}GB" -ForegroundColor White
Write-Host "    Quant:     $recommendedQuant" -ForegroundColor White
Write-Host "    Contesto:  $recommendedCtx token" -ForegroundColor White
Write-Host ""
Write-Host "    Comandi:" -ForegroundColor White
Write-Host "    ollama run glm-4.7-flash          → Chat diretta" -ForegroundColor Cyan
Write-Host "    .\glm-chat.bat                    → Shortcut chat" -ForegroundColor Cyan
Write-Host "    ollama list                       → Modelli installati" -ForegroundColor Cyan
Write-Host "    ollama rm glm-4.7-flash           → Rimuovi modello" -ForegroundColor Cyan
Write-Host ""
Write-Host "    API: http://localhost:11434/v1/chat/completions" -ForegroundColor Cyan
Write-Host ""
Write-Host "    🧪 BortyLab — Buon hacking!" -ForegroundColor Magenta
Write-Host ""
