#!/bin/bash
# ============================================================
# 🚀 GLM-4.7-Flash — Installazione Completa per Linux
# Supporta: Ubuntu/Debian, Fedora/RHEL, Arch/Manjaro
# GPU: NVIDIA CUDA, AMD ROCm, CPU-only
# By BortyLab 🧪
# ============================================================

set -e

# Colori
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'
BOLD='\033[1m'

print_header() {
    echo ""
    echo -e "${MAGENTA}╔══════════════════════════════════════════════╗${NC}"
    echo -e "${MAGENTA}║${NC}  ${BOLD}🧪 BortyLab — GLM-4.7-Flash Installer${NC}       ${MAGENTA}║${NC}"
    echo -e "${MAGENTA}║${NC}  ${CYAN}Linux Edition (NVIDIA/AMD/CPU)${NC}              ${MAGENTA}║${NC}"
    echo -e "${MAGENTA}╚══════════════════════════════════════════════╝${NC}"
    echo ""
}

print_step() { echo -e "${CYAN}[$(date +%H:%M:%S)]${NC} ${BOLD}$1${NC}"; }
print_ok()   { echo -e "  ${GREEN}✅ $1${NC}"; }
print_warn() { echo -e "  ${YELLOW}⚠️  $1${NC}"; }
print_err()  { echo -e "  ${RED}❌ $1${NC}"; }

# ============================================================
print_header

# --- Verifica Linux ---
if [[ "$(uname)" != "Linux" ]]; then
    print_err "Questo script è per Linux."
    exit 1
fi

# --- Rileva distribuzione ---
print_step "Rilevamento sistema..."

if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO=$ID
    DISTRO_NAME=$PRETTY_NAME
else
    DISTRO="unknown"
    DISTRO_NAME="Unknown Linux"
fi

ARCH=$(uname -m)
TOTAL_RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
TOTAL_RAM_GB=$((TOTAL_RAM_KB / 1048576))
KERNEL=$(uname -r)

echo ""
echo -e "  ${BOLD}Distro:${NC}   $DISTRO_NAME"
echo -e "  ${BOLD}Kernel:${NC}   $KERNEL"
echo -e "  ${BOLD}Arch:${NC}     $ARCH"
echo -e "  ${BOLD}RAM:${NC}      ${TOTAL_RAM_GB}GB"

# --- Rileva GPU ---
GPU_TYPE="cpu"
GPU_NAME="Nessuna GPU dedicata"

if command -v nvidia-smi &> /dev/null; then
    GPU_TYPE="nvidia"
    GPU_NAME=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1 || echo "NVIDIA GPU")
    GPU_VRAM=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits 2>/dev/null | head -1 || echo "0")
    GPU_VRAM_GB=$((GPU_VRAM / 1024))
    echo -e "  ${BOLD}GPU:${NC}      $GPU_NAME (${GPU_VRAM_GB}GB VRAM)"
elif [ -d /sys/class/drm ] && ls /sys/class/drm/card*/device/vendor 2>/dev/null | xargs grep -l "0x1002" &>/dev/null; then
    GPU_TYPE="amd"
    GPU_NAME="AMD GPU (ROCm)"
    echo -e "  ${BOLD}GPU:${NC}      $GPU_NAME"
else
    echo -e "  ${BOLD}GPU:${NC}      CPU-only mode"
fi

echo ""

# --- Raccomandazioni RAM ---
if [ "$TOTAL_RAM_GB" -lt 8 ]; then
    print_err "Servono almeno 8GB di RAM. Hai ${TOTAL_RAM_GB}GB."
    exit 1
elif [ "$TOTAL_RAM_GB" -lt 16 ]; then
    RECOMMENDED_QUANT="q2_k"
    RECOMMENDED_CTX=2048
    print_warn "RAM limitata (${TOTAL_RAM_GB}GB) — Q2_K con contesto 2K"
elif [ "$TOTAL_RAM_GB" -lt 24 ]; then
    RECOMMENDED_QUANT="q4_k_m"
    RECOMMENDED_CTX=4096
    print_ok "16GB OK — Q4_K_M con contesto 4K"
elif [ "$TOTAL_RAM_GB" -lt 48 ]; then
    RECOMMENDED_QUANT="q4_k_m"
    RECOMMENDED_CTX=8192
    print_ok "${TOTAL_RAM_GB}GB — Q4_K_M con contesto 8K"
else
    RECOMMENDED_QUANT="q8_0"
    RECOMMENDED_CTX=16384
    print_ok "${TOTAL_RAM_GB}GB — Q8_0 con contesto 16K+"
fi

echo ""

# --- Funzione: installa pacchetti per distro ---
install_pkg() {
    local pkg_name="$1"
    local apt_name="${2:-$1}"
    local dnf_name="${3:-$1}"
    local pac_name="${4:-$1}"

    case "$DISTRO" in
        ubuntu|debian|linuxmint|pop)
            sudo apt-get install -y "$apt_name" ;;
        fedora|rhel|centos|rocky|alma)
            sudo dnf install -y "$dnf_name" ;;
        arch|manjaro|endeavouros)
            sudo pacman -S --noconfirm "$pac_name" ;;
        opensuse*|sles)
            sudo zypper install -y "$apt_name" ;;
        *)
            print_warn "Distro non riconosciuta. Installa '$pkg_name' manualmente."
            ;;
    esac
}

# --- 1. Aggiorna package manager ---
print_step "Aggiornamento package manager..."

case "$DISTRO" in
    ubuntu|debian|linuxmint|pop)
        sudo apt-get update -qq
        print_ok "apt aggiornato" ;;
    fedora|rhel|centos|rocky|alma)
        sudo dnf check-update -q || true
        print_ok "dnf aggiornato" ;;
    arch|manjaro|endeavouros)
        sudo pacman -Sy --noconfirm
        print_ok "pacman aggiornato" ;;
    opensuse*|sles)
        sudo zypper refresh -q
        print_ok "zypper aggiornato" ;;
esac

echo ""

# --- 2. Dipendenze base ---
print_step "Installazione dipendenze..."

# curl
if command -v curl &> /dev/null; then
    print_ok "curl presente"
else
    install_pkg "curl"
    print_ok "curl installato"
fi

# wget
if command -v wget &> /dev/null; then
    print_ok "wget presente"
else
    install_pkg "wget"
    print_ok "wget installato"
fi

# jq
if command -v jq &> /dev/null; then
    print_ok "jq presente"
else
    install_pkg "jq"
    print_ok "jq installato"
fi

# Python 3
if command -v python3 &> /dev/null; then
    PY_VERSION=$(python3 --version 2>&1)
    print_ok "Python: $PY_VERSION"
else
    install_pkg "python3" "python3" "python3" "python"
    print_ok "Python 3 installato"
fi

# pip
if python3 -m pip --version &> /dev/null 2>&1; then
    print_ok "pip presente"
else
    install_pkg "pip" "python3-pip" "python3-pip" "python-pip"
    print_ok "pip installato"
fi

# Python venv (serve su alcune distro)
case "$DISTRO" in
    ubuntu|debian|linuxmint|pop)
        if ! python3 -c "import venv" 2>/dev/null; then
            sudo apt-get install -y python3-venv
            print_ok "python3-venv installato"
        fi
        ;;
esac

echo ""

# --- 3. Driver GPU (opzionale) ---
print_step "Controllo driver GPU..."

if [ "$GPU_TYPE" = "nvidia" ]; then
    # Verifica CUDA
    if command -v nvcc &> /dev/null; then
        CUDA_V=$(nvcc --version | grep "release" | awk '{print $6}' | sed 's/,//')
        print_ok "CUDA presente: $CUDA_V"
    else
        print_warn "CUDA toolkit non trovato."
        echo -e "  ${YELLOW}Per prestazioni ottimali con NVIDIA, installa CUDA:${NC}"
        echo -e "  ${CYAN}  Ubuntu: sudo apt install nvidia-cuda-toolkit${NC}"
        echo -e "  ${CYAN}  Fedora: sudo dnf install cuda${NC}"
        echo ""
        echo -e "  ${YELLOW}Ollama userà comunque la GPU se i driver sono OK.${NC}"
    fi

    # Verifica driver
    DRIVER_V=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null | head -1)
    if [ -n "$DRIVER_V" ]; then
        print_ok "Driver NVIDIA: $DRIVER_V"
    fi

elif [ "$GPU_TYPE" = "amd" ]; then
    if command -v rocm-smi &> /dev/null; then
        print_ok "ROCm presente"
    else
        print_warn "ROCm non trovato. Per GPU AMD:"
        echo -e "  ${CYAN}  https://rocm.docs.amd.com/en/latest/deploy/linux/quick_start.html${NC}"
    fi
else
    print_warn "Nessuna GPU rilevata — useremo CPU-only (più lento)"
fi

echo ""

# --- 4. Librerie Python ---
print_step "Installazione librerie Python..."

python3 -m pip install --quiet --upgrade --user ollama openai requests
print_ok "ollama, openai, requests installati"

echo ""

# --- 5. Ollama ---
print_step "Installazione Ollama..."

if command -v ollama &> /dev/null; then
    OLLAMA_V=$(ollama --version 2>/dev/null || echo "installed")
    print_ok "Ollama già installato: $OLLAMA_V"
else
    echo -e "  ${CYAN}Download da ollama.com...${NC}"
    curl -fsSL https://ollama.com/install.sh | sh
    print_ok "Ollama installato"
fi

echo ""

# --- 6. Configura Ollama come servizio systemd ---
print_step "Configurazione servizio systemd..."

if systemctl is-active --quiet ollama 2>/dev/null; then
    print_ok "Servizio ollama già attivo"
elif systemctl list-unit-files | grep -q ollama 2>/dev/null; then
    sudo systemctl enable ollama
    sudo systemctl start ollama
    sleep 3
    print_ok "Servizio ollama avviato e abilitato"
else
    # Avvio manuale se systemd non ha il servizio
    if ! curl -s http://localhost:11434/api/tags &> /dev/null; then
        ollama serve &>/dev/null &
        sleep 3
    fi
    print_ok "Ollama avviato manualmente"
fi

# Verifica server
if curl -s http://localhost:11434/api/tags &> /dev/null; then
    print_ok "Server attivo su http://localhost:11434"
else
    print_warn "Server non raggiungibile, riprovo..."
    sleep 5
    if curl -s http://localhost:11434/api/tags &> /dev/null; then
        print_ok "Server attivo"
    else
        print_err "Non riesco ad avviare il server. Prova: ollama serve"
    fi
fi

echo ""

# --- 7. Download modello ---
print_step "Download GLM-4.7-Flash..."
echo -e "  ${CYAN}Quantizzazione: ${BOLD}${RECOMMENDED_QUANT}${NC}"
echo ""

ollama pull glm-4.7-flash

print_ok "Modello scaricato!"
echo ""

# --- 8. Test ---
print_step "Test rapido..."

RESPONSE=$(curl -s http://localhost:11434/api/generate \
    -d "{\"model\":\"glm-4.7-flash\",\"prompt\":\"Rispondi in max 10 parole: sei operativo?\",\"stream\":false}" \
    | python3 -c "import sys,json; print(json.load(sys.stdin).get('response','OK'))" 2>/dev/null || echo "Test completato")

echo -e "  ${GREEN}🤖 GLM-4.7-Flash: ${RESPONSE}${NC}"
echo ""

# --- 9. Shortcut ---
LAUNCH_SCRIPT="$HOME/.local/bin/glm-chat"
mkdir -p "$HOME/.local/bin"

cat > "$LAUNCH_SCRIPT" << 'SCRIPT'
#!/bin/bash
if ! curl -s http://localhost:11434/api/tags &> /dev/null; then
    echo "🔄 Avvio Ollama..."
    ollama serve &>/dev/null &
    sleep 3
fi
echo "🧪 BortyLab — GLM-4.7-Flash Chat"
echo "Digita /bye per uscire"
echo ""
ollama run glm-4.7-flash
SCRIPT

chmod +x "$LAUNCH_SCRIPT"

if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
    export PATH="$HOME/.local/bin:$PATH"
fi

print_ok "Shortcut creato: glm-chat"
echo ""

# --- Riepilogo ---
echo -e "${MAGENTA}╔══════════════════════════════════════════════╗${NC}"
echo -e "${MAGENTA}║${NC}  ${GREEN}${BOLD}🎉 INSTALLAZIONE COMPLETATA!${NC}                ${MAGENTA}║${NC}"
echo -e "${MAGENTA}╚══════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BOLD}Sistema:${NC}   $DISTRO_NAME"
echo -e "  ${BOLD}GPU:${NC}       $GPU_NAME ($GPU_TYPE)"
echo -e "  ${BOLD}RAM:${NC}       ${TOTAL_RAM_GB}GB"
echo -e "  ${BOLD}Quant:${NC}     $RECOMMENDED_QUANT"
echo -e "  ${BOLD}Contesto:${NC}  $RECOMMENDED_CTX token"
echo ""
echo -e "  ${BOLD}Comandi:${NC}"
echo -e "  ${CYAN}glm-chat${NC}                           → Chat rapida"
echo -e "  ${CYAN}ollama run glm-4.7-flash${NC}           → Chat diretta"
echo -e "  ${CYAN}sudo systemctl status ollama${NC}       → Stato servizio"
echo -e "  ${CYAN}sudo systemctl restart ollama${NC}      → Riavvia"
echo ""
echo -e "  ${BOLD}API:${NC} ${CYAN}http://localhost:11434/v1/chat/completions${NC}"
echo ""
echo -e "  ${BOLD}🧪 BortyLab — Buon hacking!${NC}"
echo ""
