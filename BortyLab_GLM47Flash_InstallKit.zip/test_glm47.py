#!/usr/bin/env python3
"""
🧪 BortyLab — GLM-4.7-Flash Test & Utility
Cross-platform: macOS, Linux, Windows
Verifica installazione, benchmark, e esempi d'uso.
"""

import json
import time
import sys
import platform
import subprocess
import shutil

# ============================================================
# Config
# ============================================================
OLLAMA_BASE = "http://localhost:11434"
MODEL = "glm-4.7-flash"

# ============================================================
# Helpers
# ============================================================
def color(text, code):
    """Colora il testo (ignora su Windows senza supporto ANSI)."""
    if sys.platform == "win32":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
        except Exception:
            return text
    return f"\033[{code}m{text}\033[0m"

def green(t):   return color(t, "32")
def red(t):     return color(t, "31")
def cyan(t):    return color(t, "36")
def yellow(t):  return color(t, "33")
def bold(t):    return color(t, "1")
def magenta(t): return color(t, "35")

def header():
    print()
    print(magenta("╔══════════════════════════════════════════════╗"))
    print(magenta("║") + bold("  🧪 BortyLab — GLM-4.7-Flash Test Suite     ") + magenta("║"))
    print(magenta("╚══════════════════════════════════════════════╝"))
    print()

# ============================================================
# Checks
# ============================================================
def check_system():
    """Mostra info di sistema."""
    print(bold("📋 Sistema:"))
    print(f"  OS:       {platform.platform()}")
    print(f"  Python:   {platform.python_version()}")
    print(f"  Arch:     {platform.machine()}")
    print()

def check_ollama():
    """Verifica che Ollama sia installato e in esecuzione."""
    print(bold("🔍 Controllo Ollama..."))

    # Binario
    ollama_path = shutil.which("ollama")
    if ollama_path:
        print(f"  {green('✅')} Binario: {ollama_path}")
    else:
        print(f"  {red('❌')} Ollama non trovato nel PATH")
        print(f"  {yellow('→')} Installa da https://ollama.com")
        return False

    # Server
    try:
        import urllib.request
        req = urllib.request.Request(f"{OLLAMA_BASE}/api/tags")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            models = [m["name"] for m in data.get("models", [])]
            print(f"  {green('✅')} Server attivo su {OLLAMA_BASE}")
            print(f"  {green('✅')} Modelli installati: {len(models)}")
            for m in models:
                marker = "→" if MODEL in m else " "
                print(f"      {marker} {m}")
    except Exception as e:
        print(f"  {red('❌')} Server non raggiungibile: {e}")
        print(f"  {yellow('→')} Avvia con: ollama serve")
        return False

    # Modello specifico
    if any(MODEL in m for m in models):
        print(f"  {green('✅')} {MODEL} trovato!")
    else:
        print(f"  {yellow('⚠️')}  {MODEL} non installato")
        print(f"  {yellow('→')} Installa con: ollama pull {MODEL}")
        return False

    print()
    return True

def check_python_deps():
    """Verifica le dipendenze Python."""
    print(bold("📦 Dipendenze Python..."))

    deps = {
        "ollama": "ollama",
        "openai": "openai",
        "requests": "requests",
    }

    all_ok = True
    for name, module in deps.items():
        try:
            __import__(module)
            print(f"  {green('✅')} {name}")
        except ImportError:
            print(f"  {red('❌')} {name} — pip install {name}")
            all_ok = False

    print()
    return all_ok

# ============================================================
# Tests
# ============================================================
def test_basic_chat():
    """Test base: invio messaggio e ricezione risposta."""
    print(bold("💬 Test 1: Chat base"))

    import urllib.request
    payload = json.dumps({
        "model": MODEL,
        "prompt": "Rispondi in una sola riga: quanto fa 2+2?",
        "stream": False
    }).encode()

    req = urllib.request.Request(
        f"{OLLAMA_BASE}/api/generate",
        data=payload,
        headers={"Content-Type": "application/json"}
    )

    start = time.time()
    with urllib.request.urlopen(req, timeout=120) as resp:
        data = json.loads(resp.read())
    elapsed = time.time() - start

    response_text = data.get("response", "").strip()
    eval_count = data.get("eval_count", 0)
    eval_duration = data.get("eval_duration", 1) / 1e9  # nanosec → sec
    tok_per_sec = eval_count / eval_duration if eval_duration > 0 else 0

    print(f"  🤖 Risposta: {green(response_text)}")
    print(f"  ⏱  Tempo totale: {elapsed:.2f}s")
    print(f"  📊 Token generati: {eval_count}")
    print(f"  🚀 Velocità: {tok_per_sec:.1f} token/s")
    print()
    return tok_per_sec

def test_coding():
    """Test coding: genera una funzione Python."""
    print(bold("💻 Test 2: Generazione codice"))

    import urllib.request
    payload = json.dumps({
        "model": MODEL,
        "prompt": "Scrivi una funzione Python che calcola il numero di Fibonacci n-esimo. Solo il codice, nessuna spiegazione.",
        "stream": False
    }).encode()

    req = urllib.request.Request(
        f"{OLLAMA_BASE}/api/generate",
        data=payload,
        headers={"Content-Type": "application/json"}
    )

    start = time.time()
    with urllib.request.urlopen(req, timeout=120) as resp:
        data = json.loads(resp.read())
    elapsed = time.time() - start

    response_text = data.get("response", "").strip()
    has_def = "def " in response_text
    has_fib = "fib" in response_text.lower()

    print(f"  ⏱  Tempo: {elapsed:.2f}s")
    print(f"  {'✅' if has_def else '❌'} Contiene definizione funzione")
    print(f"  {'✅' if has_fib else '❌'} Contiene logica Fibonacci")
    print()

    # Mostra prime 10 righe
    lines = response_text.split("\n")[:10]
    for line in lines:
        print(f"  {cyan(line)}")
    if len(response_text.split("\n")) > 10:
        print(f"  {yellow('... (troncato)')}")
    print()

def test_ollama_python_lib():
    """Test con la libreria Python ollama."""
    print(bold("🐍 Test 3: Libreria Python ollama"))

    try:
        from ollama import chat

        start = time.time()
        response = chat(
            model=MODEL,
            messages=[{"role": "user", "content": "Ciao! Dimmi chi sei in una riga."}],
        )
        elapsed = time.time() - start

        msg = response.message.content.strip()
        print(f"  🤖 {green(msg)}")
        print(f"  ⏱  Tempo: {elapsed:.2f}s")
        print()
    except ImportError:
        print(f"  {yellow('⚠️')} Libreria ollama non installata: pip install ollama")
        print()
    except Exception as e:
        print(f"  {red('❌')} Errore: {e}")
        print()

def test_openai_compat():
    """Test compatibilità API OpenAI."""
    print(bold("🔌 Test 4: Compatibilità API OpenAI"))

    try:
        from openai import OpenAI

        client = OpenAI(
            base_url=f"{OLLAMA_BASE}/v1",
            api_key="not-needed",
        )

        start = time.time()
        completion = client.chat.completions.create(
            model=MODEL,
            messages=[{"role": "user", "content": "Dimmi 'test OK' e nient'altro."}],
            max_tokens=20,
        )
        elapsed = time.time() - start

        msg = completion.choices[0].message.content.strip()
        print(f"  🤖 {green(msg)}")
        print(f"  ⏱  Tempo: {elapsed:.2f}s")
        print(f"  {green('✅')} API OpenAI compatibile!")
        print()
    except ImportError:
        print(f"  {yellow('⚠️')} Libreria openai non installata: pip install openai")
        print()
    except Exception as e:
        print(f"  {red('❌')} Errore: {e}")
        print()

# ============================================================
# Main
# ============================================================
def main():
    header()
    check_system()

    if not check_ollama():
        print(red("Installazione non completa. Esegui prima lo script di setup."))
        sys.exit(1)

    check_python_deps()

    print(magenta("═" * 48))
    print(bold("  🧪 Avvio test suite..."))
    print(magenta("═" * 48))
    print()

    tok_s = test_basic_chat()
    test_coding()
    test_ollama_python_lib()
    test_openai_compat()

    # Riepilogo
    print(magenta("═" * 48))
    print(bold("  📊 Riepilogo"))
    print(magenta("═" * 48))
    print()
    print(f"  Modello:      {MODEL}")
    print(f"  Velocità:     {tok_s:.1f} token/s")
    print(f"  Piattaforma:  {platform.system()} {platform.machine()}")
    print()

    if tok_s > 50:
        print(f"  {green('🔥 Prestazioni eccellenti!')}")
    elif tok_s > 20:
        print(f"  {green('👍 Prestazioni buone')}")
    elif tok_s > 5:
        print(f"  {yellow('⚡ Prestazioni accettabili (CPU o RAM limitata)')}")
    else:
        print(f"  {yellow('🐌 Lento — verifica GPU/RAM disponibile')}")

    print()
    print(f"  {bold('🧪 BortyLab — Test completati!')}")
    print()

if __name__ == "__main__":
    main()
